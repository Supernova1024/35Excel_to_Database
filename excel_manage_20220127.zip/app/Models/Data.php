<?php

namespace App\Models;

// use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use EllGreen\LaravelLoadFile\Laravel\Traits\LoadsFiles;
class Data extends Model
{
    // use HasFactory;
    use LoadsFiles;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'phone',
        'source',
        'leadtype',
        'email',
        'date',
        'state'
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [];
}
