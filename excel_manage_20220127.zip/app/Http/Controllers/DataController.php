<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Data;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class DataController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    } 

    public function index(Request $request)
    {
        $data = [
            'count_user' => User::latest()->count(),
            'count_data' => Data::latest()->count(),
            'menu'       => 'menu.v_menu_admin',
            'content'    => 'content.view_data',
            'title'    => 'Table Data'
        ];

        if ($request->ajax()) {
            $q_data = Data::select('*')->orderByDesc('created_at');
            return Datatables::of($q_data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
     
                        $btn = '<div data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Edit" class="btn btn-sm btn-icon btn-outline-success btn-circle mr-2 edit editData"><i class=" fi-rr-edit"></i></div>';
                        $btn = $btn.' <div data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Delete" class="btn btn-sm btn-icon btn-outline-danger btn-circle mr-2 deleteData"><i class="fi-rr-trash"></i></div>';
 
                         return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }

        return view('layouts.v_template',$data);
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        Data::updateOrCreate(
                [
                 'phone' => $request->phone,
                 'source' => $request->source,
                 'leadtype' => $request->leadtype,
                 'email' => $request->email,
                 'date' => $request->date,
                 'state' => $request->state,
                ]);        

        return response()->json(['success'=>'Data saved successfully!']);
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $Data = Data::find($id);
        return response()->json($Data);

    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        Data::find($id)->delete();

        return response()->json(['success'=>'Customer deleted!']);
    }
}
