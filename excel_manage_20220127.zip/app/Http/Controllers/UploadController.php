<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DataTables;
use App\Models\Data;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Rap2hpoutre\FastExcel\FastExcel;
use EllGreen\LaravelLoadFile\Laravel\Facades\LoadFile;

class UploadController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    } 

    public function index(Request $request)
    {
        $data = [
            'count_user' => User::latest()->count(),
            'count_data' => Data::latest()->count(),
            'menu'       => 'menu.v_menu_admin',
            'content'    => 'content.view_upload',
            'title'    => 'Upload CSV'
        ];

        return view('layouts.v_template',$data);
    }

    private function _import_csv($path)
    {

        $csv = $path;
        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE data FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 0 LINES (`Phone`, `Source`, `Leadtype`, `Email`, `Date`, `State`, `created_at`, `updated_at`)SET created_at=NOW(),updated_at=null", addslashes($csv));
        return DB::connection()->getpdo()->exec($query);

    }

    public function importcsv(Request $request)
    {
        $filePath = $request->file('file')->path();
        $newFilePath =  $filePath . '.' . $request->file('file')->getClientOriginalExtension();
        move_uploaded_file($filePath, $newFilePath);
        ini_set('MAX_EXECUTION_TIME', 600);
        $this->_import_csv($newFilePath);

        $data = [
            'count_user' => User::latest()->count(),
            'count_data' => Data::latest()->count(),
            'menu'       => 'menu.v_menu_admin',
            'content'    => 'content.view_data',
            'title'    => 'Table Data'
        ];

        if ($request->ajax()) {
            $q_data = Data::select('*')->orderByDesc('created_at');
            return Datatables::of($q_data)
                    ->addIndexColumn()
                    ->addColumn('action', function($row){
     
                        $btn = '<div data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Edit" class="btn btn-sm btn-icon btn-outline-success btn-circle mr-2 edit editData"><i class=" fi-rr-edit"></i></div>';
                        $btn = $btn.' <div data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Delete" class="btn btn-sm btn-icon btn-outline-danger btn-circle mr-2 deleteData"><i class="fi-rr-trash"></i></div>';
 
                         return $btn;
                    })
                    ->rawColumns(['action'])
                    ->make(true);
        }

        return view('layouts.v_template',$data);

        // return back();
    }
}