<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><?php echo e($title); ?></h2>
                <div class="d-flex flex-row-reverse"><button
                        class="btn btn-sm btn-pill btn-outline-primary font-weight-bolder" id="createNewData"><i
                            class="fas fa-plus"></i>add data </button></div>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table" id="tableData">
                            <thead class="font-weight-bold text-center">
                                <tr>
                                    <th>No.</th>
                                    <th>Phone</th>
                                    <th>Source</th>
                                    <th>Leadtype</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>State</th>
                                    <th style="width:90px;">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                               
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal-->
<div class="modal fade" id="modal-data" data-backdrop="static" tabindex="-1" role="dialog"
    aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">Modal Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <form id="formData" name="formData">
                    <div class="form-group">

                        <input type="text" name="phone" class="form-control" id="phone" placeholder="Phone"><br>
                        <input type="text" name="source" class="form-control" id="source" placeholder="Source"><br>
                        <input type="text" name="leadtype" class="form-control" id="leadtype" placeholder="Leadtype"><br>
                        <input type="email" name="email" class="form-control" id="email" placeholder="Email"><br>
                        <input type="text" name="date" class="form-control" id="date" placeholder="Date"><br>
                        <input type="text" name="state" class="form-control" id="state" placeholder="State"><br>
                        <input type="hidden" name="data_id" id="data_id" value="">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary font-weight-bold" id="savedataBtn">Save changes</button>
            </div>
        </div>
    </div>
</div>



<?php $__env->startPush('scripts'); ?>
<script>
    $('document').ready(function () {
        // success alert
        function swal_success() {
            Swal.fire({
                position: 'top-end',
                icon: 'success',
                title: 'Your work has been saved',
                showConfirmButton: false,
                timer: 1000
            })
        }
        // error alert
        function swal_error() {
            Swal.fire({
                position: 'centered',
                icon: 'error',
                title: 'Something goes wrong !',
                showConfirmButton: true,
            })
        }
        // table serverside
        var table = $('#tableData').DataTable({
            processing: false,
            serverSide: true,
            ordering: false,
            dom: 'Bfrtip',
            buttons: [
                'copy', 'excel', 'pdf'
            ],
            ajax: "<?php echo e(route('data.index')); ?>",
            columns: [{
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'phone',
                    name: 'phone'
                },
                {
                    data: 'source',
                    name: 'source'
                },
                {
                    data: 'leadtype',
                    name: 'leadtype'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'date',
                    name: 'date'
                },
                {
                    data: 'state',
                    name: 'state'
                },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },
            ]
        });
        
        // csrf token
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        // initialize btn add
        $('#createNewData').click(function () {
            $('#savedataBtn').val("create data");
            $('#data_id').val('');
            $('#formData').trigger("reset");
            $('#modal-data').modal('show');
        });
        // initialize btn edit
        $('body').on('click', '.editData', function () {
            var data_id = $(this).data('id');
            $.get("<?php echo e(route('data.index')); ?>" + '/' + data_id + '/edit', function (data) {
                $('#savedataBtn').val("edit-data");
                $('#modal-data').modal('show');
                $('#data_id').val(data.id);
                $('#phone').val(data.phone);
                $('#source').val(data.source);
                $('#leadtype').val(data.leadtype);
                $('#email').val(data.email);
                $('#date').val(data.date);
                $('#state').val(data.state);
            })
        });
        // initialize btn save
        $('#savedataBtn').click(function (e) {
            e.preventDefault();
            $(this).html('Save');

            $.ajax({
                data: $('#formData').serialize(),
                url: "<?php echo e(route('data.store')); ?>",
                type: "POST",
                dataType: 'json',
                success: function (data) {

                    $('#formData').trigger("reset");
                    $('#modal-data').modal('hide');
                    swal_success();
                    table.draw();

                },
                error: function (data) {
                    swal_error();
                    $('#savedataBtn').html('Save Changes');
                }
            });

        });
        // initialize btn delete
        $('body').on('click', '.deleteData', function () {
            var data_id = $(this).data("id");

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: "DELETE",
                        url: "<?php echo e(route('data.store')); ?>" + '/' + data_id,
                        success: function (data) {
                            swal_success();
                            table.draw();
                        },
                        error: function (data) {
                            swal_error();
                        }
                    });
                }
            })
        });

        // statusing


    });

</script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\1project\35. excel_to_database\me\workspace\laravel-8-boilerplate-beta-release\resources\views/content/view_data.blade.php ENDPATH**/ ?>