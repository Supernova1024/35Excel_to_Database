<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2><?php echo e($title); ?></h2>
            </div>
            <div class="card-body">
                <div class="col-md-12">
                    <form action="<?php echo e(route('upload.importcsv')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="file" class="form-control">
                        <br>
                        <button class="btn btn-success">Import CSV Data</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\1project\35. excel_to_database\me\workspace\laravel-8-boilerplate-beta-release\resources\views/content/view_upload.blade.php ENDPATH**/ ?>